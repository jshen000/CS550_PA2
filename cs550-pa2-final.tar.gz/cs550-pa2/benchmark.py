"""Reproducible PA2 local experiments; uses the existing client protocol."""
import argparse
import csv
import json
import multiprocessing as mp
import random
import statistics
import tempfile
import time
from pathlib import Path
from client import search, download

FIELDS = ['worker', 'trial', 'filename', 'start_epoch', 'end_epoch', 'elapsed_s',
          'success', 'complete_owners', 'owners', 'bytes', 'sha256', 'error']


def worker(args, number, peers, local, directory, barrier):
    rng = random.Random(args.seed + number)
    output = directory / f'worker-{number}.csv'
    barrier.wait(timeout=60)
    if args.start_at:
        while time.time() < args.start_at:
            time.sleep(min(0.1, args.start_at - time.time()) if time.time() < args.start_at else 0)
    with output.open('x', newline='') as f, tempfile.TemporaryDirectory(prefix='pa2-bench-') as temp:
        writer = csv.DictWriter(f, fieldnames=FIELDS)
        writer.writeheader()
        for trial in range(1, args.requests + 1):
            origin = rng.choice(peers)
            count = args.small_count if args.dataset == 'small' else args.large_count
            ext = 'txt' if args.dataset == 'small' else 'bin'
            name = f'{origin}_{args.dataset}_{rng.randrange(count):06d}.{ext}'
            owner_index = peers.index(origin)
            expected = {peers[(owner_index + k) % len(peers)] for k in range(args.factor)}
            row = dict.fromkeys(FIELDS, '')
            row.update(worker=number, trial=trial, filename=name, success=0,
                       complete_owners=0, bytes=0, start_epoch=time.time())
            started = time.perf_counter()
            try:
                owners = search(args.host, args.port, name)
                found = {p['id'] for p in owners}
                row['owners'] = ';'.join(sorted(found))
                row['complete_owners'] = int(expected.issubset(found))
                if not owners:
                    raise ValueError('No owners returned')
                if args.mode == 'get':
                    # Deterministic policy: remote owners first, then ID; fallback allowed.
                    owners.sort(key=lambda p: (p['id'] == local, p['id']))
                    errors = []
                    for owner in owners:
                        try:
                            path, size, digest = download(owner, name, temp)
                            row.update(bytes=size, sha256=digest)
                            break
                        except (OSError, ValueError, KeyError) as exc:
                            errors.append(str(exc))
                    else:
                        raise OSError('All owners failed: ' + '; '.join(errors))
                row['success'] = 1
            except (OSError, ValueError, KeyError) as exc:
                row['error'] = str(exc)
            row['elapsed_s'] = time.perf_counter() - started
            row['end_epoch'] = time.time()
            writer.writerow(row)
            f.flush()
            # Keep at most one downloaded file per worker; deletion outside measured request.
            if args.mode == 'get' and row['success']:
                path.unlink()
            if trial % 100 == 0 or trial == args.requests:
                print(f'worker={number} completed={trial}/{args.requests}', flush=True)


def summarize(directory):
    rows = []
    for path in sorted(directory.glob('worker-*.csv')):
        with path.open() as f:
            rows.extend(csv.DictReader(f))
    good = [r for r in rows if r['success'] == '1']
    times = [float(r['elapsed_s']) for r in good]
    duration = max(float(r['end_epoch']) for r in rows) - min(float(r['start_epoch']) for r in rows)
    result = dict(attempts=len(rows), successes=len(good), failures=len(rows)-len(good),
                  complete_owner_results=sum(r['complete_owners'] == '1' for r in rows),
                  duration_s=duration, successful_requests_per_s=len(good)/duration,
                  aggregate_mib_per_s=sum(int(r['bytes']) for r in good)/2**20/duration,
                  mean_success_latency_ms=statistics.mean(times)*1000 if times else None,
                  sample_stddev_success_latency_ms=statistics.stdev(times)*1000 if len(times)>1 else None)
    (directory/'summary.json').write_text(json.dumps(result, indent=2)+'\n')
    print(json.dumps(result, indent=2))


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--config', default='config/peer.json')
    p.add_argument('--cluster', default='config/cluster.json')
    p.add_argument('--host', default='127.0.0.1')
    p.add_argument('--port', type=int, default=9100)
    p.add_argument('--mode', choices=['search', 'get'], default='search')
    p.add_argument('--dataset', choices=['small', 'large'], default='small')
    p.add_argument('--requests', type=int, default=10)
    p.add_argument('--workers', type=int, default=1)
    p.add_argument('--worker-base', type=int, default=0)
    p.add_argument('--seed', type=int, default=550)
    p.add_argument('--small-count', type=int, default=100000)
    p.add_argument('--large-count', type=int, default=10)
    p.add_argument('--start-at', type=float, help='Shared future Unix epoch; requires synchronized VM clocks')
    p.add_argument('--label', required=True, help='Topology and experiment label; metadata only')
    p.add_argument('--output', required=True, help='New directory, never overwrite a prior run')
    args = p.parse_args()
    if min(args.requests, args.workers, args.small_count, args.large_count) < 1:
        p.error('Counts must be positive')
    if args.start_at and args.start_at <= time.time():
        p.error('--start-at must be in the future')
    local = json.loads(Path(args.config).read_text())
    cluster = json.loads(Path(args.cluster).read_text())
    peers = [x['id'] for x in cluster['peers']]
    args.factor = cluster['replication_factor']
    if not 1 <= args.factor <= len(peers) or len(set(peers)) != len(peers):
        p.error('Invalid cluster')
    directory = Path(args.output)
    directory.mkdir(parents=True, exist_ok=False)
    metadata = dict(arguments=vars(args), local_config=local, cluster=cluster,
                    note='Config snapshot does not verify which config the running server loaded.')
    (directory/'metadata.json').write_text(json.dumps(metadata, indent=2)+'\n')
    ctx = mp.get_context('spawn')
    barrier = ctx.Barrier(args.workers)
    jobs = [ctx.Process(target=worker, args=(args, args.worker_base+i, peers,
            local['peer_id'], directory, barrier)) for i in range(args.workers)]
    for job in jobs:
        job.start()
    for job in jobs:
        job.join()
    if any(job.exitcode for job in jobs):
        raise SystemExit('Worker failed; partial CSVs retained. Run is incomplete.')
    summarize(directory)


if __name__ == '__main__':
    main()
