"""Command-line search and direct download client."""

import argparse
import socket
import sys

from protocol import recv_message, send_message
from transfer import receive_file, valid_filename


def search(host, port, filename):
    with socket.create_connection((host, port), timeout=10) as conn:
        conn.settimeout(30)
        send_message(conn, {
            "type": "SEARCH",
            "filename": filename,
        })
        response = recv_message(conn)

    if response.get("type") != "RESULT":
        raise ValueError(f"Unexpected response: {response}")

    return response["owners"]


def download(owner, filename, output_dir):
    with socket.create_connection(
        (owner["host"], owner["port"]), timeout=5
    ) as conn:
        conn.settimeout(60)
        send_message(conn, {
            "type": "OBTAIN",
            "filename": filename,
        })
        return receive_file(conn, filename, output_dir)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("command", choices=["search", "get"])
    parser.add_argument("filename")
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=9100)
    parser.add_argument("--output", default="downloads")
    args = parser.parse_args()

    if not valid_filename(args.filename):
        parser.error("Use a filename without directory components")

    try:
        owners = search(args.host, args.port, args.filename)

        if not owners:
            print(f"Not found: {args.filename}")
            return 1

        print(f"Search results for: {args.filename}")
        for owner in owners:
            print(
                f"  {owner['id']} "
                f"{owner['host']}:{owner['port']}"
            )

        if args.command == "search":
            return 0

        # If one owner is unavailable, try another returned owner.
        for owner in owners:
            try:
                print(f"Downloading directly from {owner['id']}...")
                path, size, digest = download(
                    owner, args.filename, args.output
                )
                print(f"display file '{args.filename}'")
                print(f"Saved: {path}")
                print(f"Bytes: {size}")
                print(f"SHA-256: {digest}")
                return 0
            except (OSError, ValueError) as exc:
                print(f"Download from {owner['id']} failed: {exc}")

        print("All download attempts failed.")
        return 1

    except (OSError, ValueError, KeyError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    sys.exit(main())
