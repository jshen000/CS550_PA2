"""Stream files over TCP and verify SHA-256."""

import hashlib
import os
import tempfile
from pathlib import Path

from protocol import recv_message, send_message

CHUNK_SIZE = 1024 * 1024


def valid_filename(name):
    return (
        isinstance(name, str)
        and bool(name)
        and name not in (".", "..")
        and "/" not in name
        and "\\" not in name
        and "\x00" not in name
    )


def serve_file(conn, shared_dir, filename):
    """Send a header, exactly size bytes, then a checksum message."""
    if not valid_filename(filename):
        send_message(conn, {
            "type": "ERROR",
            "error": "Invalid filename",
        })
        return

    root = Path(shared_dir).resolve()
    path = root / filename

    if path.is_symlink() or not path.is_file():
        send_message(conn, {
            "type": "ERROR",
            "error": "File not found",
        })
        return

    # Prevent serving files outside the shared directory.
    if path.resolve().parent != root:
        send_message(conn, {
            "type": "ERROR",
            "error": "Invalid file path",
        })
        return

    try:
        source = path.open("rb")
    except OSError as exc:
        send_message(conn, {
            "type": "ERROR",
            "error": str(exc),
        })
        return

    with source:
        size = os.fstat(source.fileno()).st_size
        send_message(conn, {
            "type": "FILE",
            "filename": filename,
            "size": size,
        })

        digest = hashlib.sha256()
        remaining = size

        while remaining:
            data = source.read(min(CHUNK_SIZE, remaining))
            if not data:
                raise OSError("Source file changed during transfer")
            conn.sendall(data)
            digest.update(data)
            remaining -= len(data)

        send_message(conn, {
            "type": "CHECKSUM",
            "sha256": digest.hexdigest(),
        })


def receive_file(conn, filename, output_dir):
    """Publish the downloaded file only after checksum verification."""
    if not valid_filename(filename):
        raise ValueError("Invalid filename")

    header = recv_message(conn)
    if header.get("type") == "ERROR":
        raise OSError(header.get("error", "Download rejected"))

    if header.get("type") != "FILE":
        raise ValueError("Expected FILE response")
    if header.get("filename") != filename:
        raise ValueError("Unexpected filename")

    size = header.get("size")
    if type(size) is not int or size < 0:
        raise ValueError("Invalid file size")

    output = Path(output_dir)
    output.mkdir(parents=True, exist_ok=True)
    destination = output / filename

    fd, temporary = tempfile.mkstemp(
        prefix=".pa2-", suffix=".part", dir=output
    )

    try:
        digest = hashlib.sha256()
        remaining = size

        with os.fdopen(fd, "wb") as target:
            while remaining:
                data = conn.recv(min(CHUNK_SIZE, remaining))
                if not data:
                    raise ConnectionError("Incomplete file transfer")
                target.write(data)
                digest.update(data)
                remaining -= len(data)

        checksum = recv_message(conn)
        actual = digest.hexdigest()

        if (
            checksum.get("type") != "CHECKSUM"
            or checksum.get("sha256") != actual
        ):
            raise ValueError("SHA-256 verification failed")

        os.replace(temporary, destination)
        return destination, size, actual

    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)
