"""Pull assigned replicas using a static ring placement policy."""

import argparse
import json
import socket
import sys
from pathlib import Path

from client import download
from protocol import recv_message, send_message


def list_originals(owner):
    offset = 0

    while True:
        with socket.create_connection(
            (owner["host"], owner["port"]), timeout=5
        ) as conn:
            conn.settimeout(30)
            send_message(conn, {
                "type": "LIST_ORIGINALS",
                "offset": offset,
            })
            response = recv_message(conn)

        if response.get("type") != "ORIGINALS":
            raise ValueError(f"Unexpected response: {response}")

        for filename in response["files"]:
            if not filename.startswith(owner["id"] + "_"):
                raise ValueError("Unexpected original filename")
            yield filename

        next_offset = response["next_offset"]
        if next_offset is None:
            break
        if not isinstance(next_offset, int) or next_offset <= offset:
            raise ValueError("Invalid pagination")
        offset = next_offset


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", default="config/peer.json")
    parser.add_argument("--cluster", default="config/cluster.json")
    args = parser.parse_args()

    local = json.loads(Path(args.config).read_text())
    cluster = json.loads(Path(args.cluster).read_text())

    peers = cluster["peers"]
    ids = [peer["id"] for peer in peers]
    factor = cluster["replication_factor"]
    me = local["peer_id"]

    if len(set(ids)) != len(ids) or me not in ids:
        raise ValueError("Invalid cluster peer IDs")
    if type(factor) is not int or not 1 <= factor <= len(peers):
        raise ValueError("Invalid replication factor")
    if local["replication_factor"] != factor:
        raise ValueError("Local and cluster replication factors differ")

    completed = 0
    failures = 0

    for index, owner in enumerate(peers):
        # The original counts as one copy.
        replica_ids = [
            ids[(index + step) % len(peers)]
            for step in range(1, factor)
        ]

        if me not in replica_ids:
            continue

        print(f"{me}: pulling originals from {owner['id']}")

        try:
            for filename in list_originals(owner):
                try:
                    path, size, digest = download(
                        owner, filename, local["shared_dir"]
                    )
                    completed += 1
                    print(
                        f"REPLICA OK {filename} "
                        f"bytes={size} sha256={digest}",
                        flush=True,
                    )
                except (OSError, ValueError, KeyError) as exc:
                    failures += 1
                    print(f"REPLICA FAILED {filename}: {exc}")
        except (OSError, ValueError, KeyError) as exc:
            failures += 1
            print(f"Cannot list {owner['id']}: {exc}")

    print(f"Completed={completed}; failures={failures}")
    print("Restart this peer after all replication runs finish.")
    return 1 if failures else 0


if __name__ == "__main__":
    try:
        sys.exit(main())
    except (OSError, ValueError, KeyError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        sys.exit(1)
