"""PA2 stage 1: distributed search with reverse-path replies."""

import argparse
import json
import logging
import socket
import threading
import time
from pathlib import Path

from protocol import recv_message, send_message
from transfer import serve_file


class Peer:
    def __init__(self, config):
        self.config = config
        self.peer_id = config["peer_id"]
        self.shared = Path(config["shared_dir"])
        self.shared.mkdir(parents=True, exist_ok=True)

        # This initial version indexes files at startup.
        self.index = {
            p.name: p for p in self.shared.iterdir()
            if p.is_file() and not p.is_symlink()
        }

        self.original_names = sorted(
            name for name in self.index
            if name.startswith(self.peer_id + "_")
        )

        self.lock = threading.Lock()
        self.seen = {}
        self.pending = {}

        # Persist the sequence number to avoid reuse after restart.
        self.sequence_file = Path("config/sequence.txt")
        if self.sequence_file.exists():
            self.sequence = int(self.sequence_file.read_text())
        else:
            self.sequence = 0

        self.address = {
            "id": self.peer_id,
            "host": config["advertise_host"],
            "port": config["port"],
        }

    def next_id(self):
        with self.lock:
            self.sequence += 1
            temporary = self.sequence_file.with_suffix(".tmp")
            temporary.write_text(str(self.sequence))
            temporary.replace(self.sequence_file)
            return [self.peer_id, self.sequence]

    def send_to(self, address, message):
        try:
            with socket.create_connection(
                (address["host"], address["port"]), timeout=2
            ) as sock:
                sock.settimeout(2)
                send_message(sock, message)
        except (OSError, ValueError) as exc:
            logging.warning(
                "Cannot send %s to %s: %s",
                message["type"], address["id"], exc
            )

    def forward_query(self, message, upstream):
        if message["ttl"] <= 0:
            return

        outgoing = dict(message)
        outgoing["ttl"] -= 1
        outgoing["sender"] = self.address

        for neighbor in self.config["neighbors"]:
            if upstream and neighbor["id"] == upstream["id"]:
                continue
            logging.info(
                "FORWARD %s -> %s TTL=%s",
                message["message_id"], neighbor["id"], outgoing["ttl"]
            )
            threading.Thread(
                target=self.send_to,
                args=(neighbor, outgoing),
                daemon=True,
            ).start()

    def handle_query(self, message):
        key = tuple(message["message_id"])
        upstream = message["sender"]

        with self.lock:
            if key in self.seen:
                logging.info("DUPLICATE ignored: %s", key)
                return
            self.seen[key] = (
                upstream,
                time.monotonic() + self.config["seen_ttl"],
            )

        logging.info(
            "QUERY %s from %s file=%s TTL=%s",
            key, upstream["id"], message["filename"], message["ttl"]
        )

        if message["filename"] in self.index:
            hit = {
                "type": "HITQUERY",
                "message_id": message["message_id"],
                "ttl": message["return_ttl"],
                "filename": message["filename"],
                "owner": self.address,
            }
            logging.info("LOCAL HIT %s -> %s", key, upstream["id"])
            self.send_to(upstream, hit)

        self.forward_query(message, upstream)

    def handle_hit(self, message):
        key = tuple(message["message_id"])

        with self.lock:
            if key in self.pending:
                owner = message["owner"]
                self.pending[key][owner["id"]] = owner
                logging.info("RESULT %s owner=%s", key, owner["id"])
                return

            route = self.seen.get(key)

        if route is None:
            return

        upstream, expires = route
        if upstream is None or expires <= time.monotonic():
            return
        if message["ttl"] <= 0:
            return

        outgoing = dict(message)
        outgoing["ttl"] -= 1
        logging.info("RETURN HIT %s -> %s", key, upstream["id"])
        self.send_to(upstream, outgoing)

    def search(self, filename):
        message_id = self.next_id()
        key = tuple(message_id)

        with self.lock:
            self.seen[key] = (
                None,
                time.monotonic() + self.config["seen_ttl"],
            )
            self.pending[key] = {}
            if filename in self.index:
                self.pending[key][self.peer_id] = self.address

        message = {
            "type": "QUERY",
            "message_id": message_id,
            "ttl": self.config["query_ttl"],
            "return_ttl": self.config["query_ttl"],
            "filename": filename,
            "sender": self.address,
        }

        try:
            self.forward_query(message, None)

            # Collect results for a fixed window, including replica owners.
            time.sleep(self.config["query_timeout"])

            with self.lock:
                owners = list(self.pending[key].values())

            return {
                "type": "RESULT",
                "message_id": message_id,
                "filename": filename,
                "owners": owners,
            }
        finally:
            with self.lock:
                self.pending.pop(key, None)

    def handle_connection(self, conn):
        with conn:
            conn.settimeout(10)
            try:
                message = recv_message(conn)
                kind = message.get("type")

                if kind == "SEARCH":
                    filename = message["filename"]
                    if not isinstance(filename, str) or not filename:
                        raise ValueError("Filename must be a nonempty string")
                    send_message(conn, self.search(filename))
                elif kind == "LIST_ORIGINALS":
                    offset = int(message.get("offset", 0))
                    if offset < 0:
                        raise ValueError("Invalid offset")
                    names = self.original_names
                    page = names[offset:offset + 500]
                    next_offset = offset + len(page)
                    send_message(conn, {
                        "type": "ORIGINALS",
                        "files": page,
                        "next_offset": (
                            next_offset if next_offset < len(names) else None
                        ),
                    })
                elif kind == "OBTAIN":
                    conn.settimeout(60)
                    serve_file(conn, self.shared, message["filename"])
                elif kind == "QUERY":
                    self.handle_query(message)
                elif kind == "HITQUERY":
                    self.handle_hit(message)
                else:
                    send_message(conn, {
                        "type": "ERROR",
                        "error": "Unknown message type",
                    })
            except (
                OSError, ValueError, KeyError, TypeError
            ) as exc:
                logging.warning("Request failed: %s", exc)

    def cleanup(self):
        while True:
            time.sleep(5)
            now = time.monotonic()
            with self.lock:
                expired = [
                    key for key, (_, deadline) in self.seen.items()
                    if deadline <= now and key not in self.pending
                ]
                for key in expired:
                    del self.seen[key]

    def run(self):
        threading.Thread(target=self.cleanup, daemon=True).start()

        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as server:
            server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            server.bind((
                self.config["bind_host"],
                self.config["port"],
            ))
            server.listen(128)

            logging.info(
                "%s listening on %s:%s; indexed %s files",
                self.peer_id,
                self.config["bind_host"],
                self.config["port"],
                len(self.index),
            )

            while True:
                conn, _ = server.accept()
                threading.Thread(
                    target=self.handle_connection,
                    args=(conn,),
                    daemon=True,
                ).start()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", default="config/peer.json")
    args = parser.parse_args()

    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s %(levelname)s %(message)s",
    )

    config = json.loads(Path(args.config).read_text())
    try:
        Peer(config).run()
    except KeyboardInterrupt:
        logging.info("Peer stopped")


if __name__ == "__main__":
    main()
