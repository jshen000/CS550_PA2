"""Generate uniquely named PA2 datasets without overwriting files."""

import argparse
import json
import os
from pathlib import Path


def create_file(path, size, binary):
    if path.exists():
        if not path.is_file() or path.stat().st_size != size:
            raise ValueError(f"Existing file has unexpected size: {path}")
        return False

    block = (
        os.urandom(min(size, 1024 * 1024))
        if binary
        else (b"PA2 text data\n" * 1024)
    )

    try:
        with path.open("xb") as output:
            remaining = size
            while remaining:
                chunk = block[:min(remaining, len(block))]
                output.write(chunk)
                remaining -= len(chunk)
    except BaseException:
        path.unlink(missing_ok=True)
        raise

    return True


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", default="config/peer.json")
    parser.add_argument("--small-count", type=int, default=100000)
    parser.add_argument("--large-count", type=int, default=10)
    args = parser.parse_args()

    if args.small_count < 0 or args.large_count < 0:
        parser.error("File counts must be nonnegative")

    config = json.loads(Path(args.config).read_text())
    root = Path(config["shared_dir"])
    root.mkdir(parents=True, exist_ok=True)
    peer = config["peer_id"]

    # Decimal units: 10 KB = 10,000 bytes; 100 MB = 100,000,000 bytes.
    datasets = [
        ("small", args.small_count, 10000, False, "txt"),
        ("large", args.large_count, 100000000, True, "bin"),
    ]

    for label, count, size, binary, extension in datasets:
        created = 0
        for index in range(count):
            path = root / f"{peer}_{label}_{index:06d}.{extension}"
            created += create_file(path, size, binary)

            if (index + 1) % 10000 == 0 or index + 1 == count:
                print(
                    f"{label}: {index + 1}/{count}; "
                    f"new files={created}",
                    flush=True,
                )

    print("Dataset generation complete.")


if __name__ == "__main__":
    main()
