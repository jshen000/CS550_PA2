"""Length-prefixed JSON messages over TCP."""

import json
import struct

MAX_MESSAGE = 1024 * 1024


def recv_exact(sock, length):
    """TCP may return fewer bytes than requested."""
    data = bytearray()
    while len(data) < length:
        chunk = sock.recv(length - len(data))
        if not chunk:
            raise ConnectionError("Connection closed before message completed")
        data.extend(chunk)
    return bytes(data)


def send_message(sock, message):
    payload = json.dumps(message).encode("utf-8")
    if len(payload) > MAX_MESSAGE:
        raise ValueError("Message too large")
    sock.sendall(struct.pack("!I", len(payload)) + payload)


def recv_message(sock):
    length = struct.unpack("!I", recv_exact(sock, 4))[0]
    if length > MAX_MESSAGE:
        raise ValueError("Message too large")
    message = json.loads(recv_exact(sock, length).decode("utf-8"))
    if not isinstance(message, dict):
        raise ValueError("Expected a JSON object")
    return message
