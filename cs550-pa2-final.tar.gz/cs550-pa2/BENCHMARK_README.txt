CS550 PA2 local benchmark supplement

Install benchmark.py, Makefile and this guide into ~/cs550-pa2 on each VM.
This supplement does not replace peer.py, configs, sequence.txt or datasets.
Python 3 standard library only. Run make check first.

Start each peer with its own configuration in a separate terminal:
  python3 -u peer.py --config config/peer.json
For chain/star use config/peer.chain.json on all three VMs instead.
Check actual running processes with pgrep -af 'python3.*peer.py'. The benchmark
saves the selected config but cannot verify what config the server loaded.
Use equal query_timeout and query_ttl settings for comparable runs.

Smoke test on vbox1 (normal config):
  python3 -u benchmark.py --label normal-smoke --requests 10 --output results/normal-smoke-vbox1
Every output path must be NEW. Existing runs are never overwritten.

Single-client latency, on vbox1 only:
  python3 -u benchmark.py --label normal-latency --requests 10000 --output results/normal-latency-vbox1
This takes at least 2h47m with a 1-second search window. Prevent host sleep.
Repeat using --config config/peer.chain.json and a NEW label/output directory
only after all three servers have switched to the chain configs.

Nine concurrent clients: run three workers on EACH VM. Set worker-base to
0 on vbox1, 3 on vbox2, 6 on vbox3. Use the SAME --start-at future Unix epoch
on all three and verify their clocks agree first (date +%s). Leave enough
lead time to start every command. Do not type the placeholder literally.
  python3 -u benchmark.py --label normal-query-load --workers 3 --worker-base 0 --requests 10000 --start-at FUTURE_EPOCH --output results/normal-query-load-vbox1
Use host-specific output names and worker-base on vbox2/vbox3.
For large transfer workload, same coordination, add:
  --mode get --dataset large --requests 10
For optional small transfer workload, add:
  --mode get --dataset small --requests 10000
Each worker issues requests sequentially; workers are concurrent processes.
No automatic retry of failed requests. All request outcomes are saved.

Metrics and experiment interpretation
- Uniform random selection of origin peer and generated file index, with
  replacement. Defaults match generate_data.py (100000 small, 10 large).
- Fixed seed + globally unique worker ID gives repeatable distinct streams.
- Search success = at least one owner. complete_owners separately checks all
  expected ring-placement owners, including replicas, using cluster order.
- Downloads include SEARCH and OBTAIN, checksum validation and file writing.
  Prefer remote owner relative to the local config peer, then sort by ID;
  fall back to other owners on error. This differs from client.py's first
  returned-owner selection and must be recorded in reports.
- Each worker uses temporary output outside shared/. Deletes successful files
  after timing; at most one downloaded file per worker remains at a time.
- summary.json gives latency mean and SAMPLE standard deviation (n-1) for
  successful requests, plus failures and complete-owner counts.
- Per-VM throughput = successful operations / local run wall-clock span.
  Transfer throughput = verified successful bytes / that same span / 2^20.
  For cluster throughput, merge all nine worker CSVs: sum successful work
  divided by latest end_epoch minus earliest start_epoch across all VMs.
  DO NOT add per-VM rates or average individual request rates as cluster rate.
  Clock synchronization is required for that cross-VM interval.
- Throughput variation requires repeated whole runs; request latency standard
  deviation is not throughput standard deviation. Repeat workloads preferably
  three times with distinct output directories, then compare run-level rates.
- Fixed wait, shared host CPU/disk, filesystem caching, and local replica
  presence affect results. Three local VMs are not a 17-VM Chameleon evaluation.
- The three-node chain is also a three-node star centered at peer2. It is not
  a 4x4 mesh. No PA1 centralized adapter is included; PA1 source is still needed.

Review of supplied code
- Query duplicate suppression, reverse-path HITQUERY forwarding, TTL fields,
  persistent peer/sequence IDs and checksum-verified streamed transfer exist.
- Search explicitly sleeps for query_timeout, explaining ~1-second latency.
- Every connection and forward creates a thread: monitor load and errors;
  no bounded worker pool or admission control is implemented.
- Startup-only indexing requires restart after replication. Startup also
  indexes leftover .pa2-*.part files; they should be excluded in a future fix.
- Sequence persistence uses config/sequence.txt relative to working directory;
  one peer per VM/project directory is assumed. Do not run multiple peers in
  the same working directory with a shared sequence file.
- Sequence replace is not fsync-protected against sudden power loss.
- Original replication redownloads existing files. Resume logic used in the
  conversation skipped final files; it did not revalidate old file contents.
- 4GB handling is streamed but no actual 4GB transfer was tested here.

Validation performed by assistant
Syntax check passed against supplied source. Isolated three-peer loopback
chain: 15 concurrent random searches, 6 binary query+obtain operations, and
source-stop replica lookup passed. Synthetic files and .08-second timeout
were used only in this smoke test. These are not VM performance measurements.

Existing user VM CSVs (30 requests each)
Chain vbox1: mean 1012.324779 ms; sample stddev 16.124971 ms.
Normal vbox1: mean 1023.754038 ms; sample stddev 35.137763 ms.
Both returned both expected owners in all trials. vbox2 CSVs were not uploaded.

Remaining submission work
PA1 centralized comparison; scaled concurrent workloads; real 4GB test if
resources permit; charts and report; complete run manual; output evidence;
honest hourly development log including all AI prompts; final package.
Do not invent missing experiment results, development hours or prompts.
