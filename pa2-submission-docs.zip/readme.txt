CS550 PA2 - Decentralized file sharing

ENVIRONMENT
Python 3 standard library; one peer per VM/project directory. Local evaluation
used three VirtualBox VMs. Chameleon Ubuntu 22.04 compatibility is unverified.
Run all commands below from the source directory.

FILES
peer.py: threaded peer, distributed search and reverse-path replies.
client.py: search and direct download CLI.
protocol.py: socket message framing.
transfer.py: streamed files and SHA-256 verification.
replicate.py: static ring replica placement.
generate_data.py: unique text and binary dataset generation.
benchmark.py: random queries, optional obtains, CSV and JSON summaries.
config/: per-peer and cluster configuration; keep copies from every VM.
results/: original benchmark CSV, summary, metadata and log files.
logs/ and screenshots/: original output evidence.
pa2-report.pdf: evaluation, figures, screenshot and limitations.
development-log.txt: actual hourly activities and AI prompt record.

SETUP AND RUN
1. Copy source to each VM. Edit each VM config/peer.json with its unique
   peer_id, advertise_host, shared_dir and neighbors. The supplied vbox1
   config is NOT suitable unchanged for vbox2/vbox3. Allow TCP 9100.
2. Use the same config/cluster.json and replication_factor on every VM.
3. Check syntax:
     make check
4. Generate originals on EACH peer before starting it:
     python3 generate_data.py --config config/peer.json
   Defaults are 100000 x 10000-byte text and 10 x 100000000-byte binary files.
5. Start every peer in its own terminal:
     python3 -u peer.py --config config/peer.json
6. With all peers running, pull assigned replicas on EACH VM:
     python3 replicate.py --config config/peer.json --cluster config/cluster.json
   Restart all peers after replication so indexes include the replicas.
7. Search and download from vbox1:
     python3 client.py search peer3_small_063098.txt
     python3 client.py get peer3_small_063098.txt --output downloads
   Successful downloads print display file, path, byte count and SHA-256.
8. Reproduce the single-client workload only if a new run is desired:
     python3 -u benchmark.py --label normal-latency --requests 10000 --output results/normal-latency-new
   Output directory must not exist. This is NOT needed to submit the finished run.
9. For an alternate topology, start each peer with its corresponding config:
     python3 -u peer.py --config config/peer.chain.json
   Ensure each VM has its own config. A three-node chain is not a 4x4 mesh.

FAILURE DEMONSTRATION
Choose a file with two known owners. Stop the original owner's peer process
using Ctrl+C in its server terminal, then search and get through a surviving
peer that can reach the replica. Preserve output and checksum; restart the
stopped peer afterwards. This demonstration is not a full partition test.

LIMITATIONS
Only three local VMs evaluated; required Chameleon/topology/load experiments
are incomplete. Startup indexing requires restart after replication. Threads
are unbounded; replicas are not automatically repaired. A 4GB transfer was
not verified. Search waits for query_timeout even if an owner arrives early.
The 10K run wall-clock duration differs substantially from summed request
latencies; the cause is unverified. See report for actual measurements.

SUBMISSION
Use CURRENT source/configs/results from the VMs, not an old review archive.
Do not include shared/ or downloads/ bulk data: regenerate with the script.
Include original output evidence, the report and genuine development history.
